export const switchTypes = {
    off: 'Off',
    on: 'On',
}

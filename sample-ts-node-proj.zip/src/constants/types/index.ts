export const entityTypes = {
    PROTOCOL: 'protocol',
}

export const logTypes = {
    REQ_RES: 'req/res',
    AUDIT: 'audit',
    COMMON: 'common',
}
export const logSeverity = {
    INFO: 'info',
    ERROR: 'error',
    DEBUG: 'debug',
    WARN: 'warn',
}

## Project Setup

```
npm install
```
## Start Development Server

```
npm run start:dev
```
it will start the development server on the port specified in env

## Build For Production

```
npm run build
``` 

## Start The Production Server

```
npm start
```


## Fix Lint Errors

``` 
npm run lint
```
